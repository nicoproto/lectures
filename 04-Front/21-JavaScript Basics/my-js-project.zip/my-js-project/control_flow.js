const age = 14;
if (age >= 18) {
  console.log("You can vote");
} else {
  console.log("You can't vote");
}
