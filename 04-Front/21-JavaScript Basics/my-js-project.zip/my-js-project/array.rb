# fruits = []

#CRUD
# fruits.push("apple") # fruits << "apple"
# fruits[0]
# fruits[0] = "banana"
# fruits.delete_at(0)

# EACH
# beatles = ["paul", "john", "ringo", "george"]
# beatles.each do |beatle| puts beatle.upcase
# end
