// const fruits = [];

// CRUD
// fruits.push("Apple");

// fruits[0];

// fruits[0] = "Banana";

// fruits.splice(0, 1); // Delete (1 item at index 0)

// console.log(fruits)

// EACH
// const beatles = ["paul", "john", "ringo", "george"];
// beatles.forEach((beatle) => {
//   console.log(beatle.toUpperCase());
// });
