// Arrow function
// const square = (x) => {
//   return x * x;
// };

// console.log(square(10));

const sayHello = (name) => {
  return `Hi there ${name}`;
}

console.log(sayHello('Nico'));
